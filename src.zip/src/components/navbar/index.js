// import React from "react";
// import styles from "./styles.module.css";
// import Logo from "../logo";
// import MenuItem from "../menuItem";
// import { Col, Container, Row } from "react-bootstrap";
// import Button from "../button";

// const menuItems = [
//   {
//     item: "Home",
//   },
//   {
//     item: "About Me",
//   },
//   {
//     item: "Services",
//   },
//   {
//     item: "Projects",
//   },
//   {
//     item: "Testimonials",
//   },
//   {
//     item: "Contact",
//   },
// ];

// const Navbar = () => {
//   return (
//     <Container>
//       <Row>
//         <Col lg={12}>
//           <div className={styles.navbar}>
//             <div className={styles.nav_logo}>
//               <Logo />
//             </div>
//             <div className={styles.nav_items}>
//               {menuItems.map((value, index) => (
//                 <MenuItem key={index} item={value.item} />
//               ))} 
//             <Button text={"Download Cv"} size={"medium"} type={"fill"} />
//             </div>
//           </div>
//         </Col>
//       </Row>
//     </Container>
//   );
// };

// export default Navbar;


import React, { useState } from "react";
import styles from "./style.module.css";
import Logo from "../logo";
import MenuItem from "../menuItem";
import { Link } from "react-router-dom";
import { Col, Container, Row } from "react-bootstrap";
import Button from "../button";

const Navbar = () => {
    const MenuItems = [
        {
            id: 1,
            title: "Home",
            path: "/home",
        },
        {
            id: 2,
            title: "About Me",
            path: "/About Me",
        },
        {
            id: 3,
            title: "Services",
            path: "/Services",
        },
        {
            id: 4,
            title: "Projects",
            path: "/Projects",
        },
        {
            id: 5,
            title: "Testimonials",
            path: "/Testimonials",
        },
        {
            id: 6,
            title: "Contact",
            path: "/Contact",
        },
    ];
 

    const [menuOpen, setMenuOpen] = useState(false);

    const handleMenuToggle = () => {
        setMenuOpen(!menuOpen);
    };

    return (
        <div className={styles.header_navbar}>
            <Container>
                <Row className="align-items-center">
                    <Col lg={12}>
                        <div className={styles.hn_wrap}>
                            <Logo />
                            <div
                                className={`${styles.menubar} ${menuOpen ? styles.menuOpen : ""}`}
                            >
                                {MenuItems.map((item, index) => (
                                    <MenuItem key={index} item={item} />
                                ))}
                                 <div className={styles.nav_btn}>
                                <Button type={"fill"} size={"medium"} text={"Download CV"} />
                            </div>
                            </div>
                           
                            <button className={styles.menu_toggle} onClick={handleMenuToggle}>
                                ☰
                            </button>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Navbar;