import React from "react";
import styles from "./style.module.css"
import Section from "../../components/section";
import HsImg from "../../assets/images/hs-image.png"
import abtImg from "../../assets/images/about-image.png"
import { Col, Container, Row } from "react-bootstrap";
import SocialIcons from "../../components/socialIcons";
import Button from "../../components/button";
import SectionHeading from "../../components/sectionHeading";
import ProgressBar from 'react-bootstrap/ProgressBar';
import FeatureBox from "../../components/featureBox";
import Icon1 from "../../assets/images/logo-Photo.png"

const ProgressData = [
    { label: 'UX', percentage: 90 },
    { label: 'Website Design', percentage: 85 },
    { label: 'App Design', percentage: 95 },
    { label: 'Graphic Design', percentage: 90 }, 
]
const FeatureData =[
    {
        title: 'Professional Experience',
        description: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis, nisi.',
        icon : Icon1,
    },{
        title: 'Professional Experience',
        description: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis, nisi.',
        icon : Icon1,
    },{
        title: 'Professional Experience',
        description: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis, nisi.',
        icon : Icon1,
    },{
        title: 'Professional Experience',
        description: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Debitis, nisi.',
        icon : Icon1,
    },
]
const Home = () => {
  return (
    <>
      <Section pt={"120"}>
        <Container>
          <Row>
            <Col lg={6} className="d-flex align-items-center">
              <div className={styles.hs_content}>
                <h6 className={styles.intro}>Hi, I am</h6>
                <h4 className={styles.name}>Fawzi Sayed</h4>
                <h1 className={styles.title}>
                  UI & UX <br/> <span >Designer</span>
                </h1>
                <p className={styles.description}>
                Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra
                </p>
                <Button text={"Hire Me"} size={"small"}  type={"fill"} />
              </div>
            </Col>
            <Col >
            <div className={styles.hs_image}>
                <img src={HsImg} alt="hero " />
                <SocialIcons />
            </div>
            </Col>
          </Row>
        </Container>
      </Section>
      <Section pt={"60"}>
        <Container>
          <Row>
            <Col md={6}>
               <div>
                <img src={abtImg} alt="" />
               </div>
            </Col>
            <Col className="d-flex align-items-center">
            <div>
                
            <SectionHeading title={"About Me"} des={" Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra"} />
            {ProgressData.map((data,i)=>{
                return(
                <div key={i}>
                  <h6 className={styles.progress_label}>{data.label}</h6>
                  <ProgressBar  now={data.percentage}   />
                </div>
                )
 
            })}
            </div>
            </Col>
            </Row>
            </Container>
      </Section>
      <Section pt={"140"}>
            <Container>
                <Row className="justify-content-center">
                    <Col lg={8}>
                    <div className={styles.service_heading}>
                    <SectionHeading title={"Services"} des={"Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium"} />
                    </div>
                    </Col>
                </Row>
                <Row>
                    <Col lg={3}>
                    { FeatureData.map((data,i)=>{
                          return   <FeatureBox title={data.title} des={data.des} Icon={data.icon} key={i}/>
                        })
                    }
                    </Col>
                </Row>
            </Container>
      </Section>
    </>
  );
};

export default Home;
