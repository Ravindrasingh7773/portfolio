import React from "react";
import styles from "./style.module.css";
import Section from "../../components/section";
import HsImg from "../../assets/images/hs-image.png";
import abtImg from "../../assets/images/about-image.png";
import { Col, Container, Row } from "react-bootstrap";
import SocialIcons from "../../components/socialIcons";
import Button from "../../components/button";
import SectionHeading from "../../components/sectionHeading";
import ProgressBar from "react-bootstrap/ProgressBar";
import FeatureBox from "../../components/featureBox";
import Icon1 from "../../assets/images/service-image.png";
import Icon2 from "../../assets/images/service-image2.png";
import Icon3 from "../../assets/images/service-image3.png";
import Icon4 from "../../assets/images/service-image4.png";
import Img1 from "../../assets/images/project-1.png";
import Img2 from "../../assets/images/project2.png";
import Img3 from "../../assets/images/project-3.png";
import Image1 from "../../assets/images/test-1.png";
import Image2 from "../../assets/images/test-1.png";
import Image3 from "../../assets/images/test-1.png";
import ProjectBox from "../../components/projectBox";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";

// Import required Swiper modules
import { Autoplay, Keyboard, Navigation, Pagination } from "swiper/modules";

import TestimonialBox from "../../components/testimonialBox";

const ProgressData = [
  { label: "UX", percentage: 90 },
  { label: "Website Design", percentage: 85 },
  { label: "App Design", percentage: 95 },
  { label: "Graphic Design", percentage: 90 },
];

const FeatureData = [
  {
    title: "UI/UX",
    description:
      "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum",
    icon: Icon1,
  },
  {
    title: "Web Design",
    description:
      "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum",
    icon: Icon2,
  },
  {
    title: "App Design",
    description:
      "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum",
    icon: Icon3,
  },
  {
    title: "Graphic Design",
    description:
      "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum",
    icon: Icon4,
  },
];

const ProjectData = [
  {
    description: "Web Design",
    title: "AirCalling Landing Page Design ",
    image: Img1,
  },
  {
    description: "Web Design",
    title: "Business Landing Page Design ",
    image: Img2,
  },
  {
    description: "Web Design",
    title: "Ecom Web Page Design ",
    image: Img3,
  },
];
const TestData = [
  {
    quotes:
      "Lorem ipsum dolor sit amet consectetur. In enim cursus odio accumsan. Id leo urna velit neque mattis id tellus arcu condimentum. Augue dictum dolor elementum convallis dignissim malesuada commodo ultrices.",
    position: "CEO",
    name: "AirCalling Landing Page Design ",
    image: Image1,
  },
  {
    quotes:
      "Lorem ipsum dolor sit amet consectetur. In enim cursus odio accumsan. Id leo urna velit neque mattis id tellus arcu condimentum. Augue dictum dolor elementum convallis dignissim malesuada commodo ultrices.",
    position: "CEO",
    name: "Business Landing Page Design ",
    image: Image2,
  },
  {
    quotes:
      "Lorem ipsum dolor sit amet consectetur. In enim cursus odio accumsan. Id leo urna velit neque mattis id tellus arcu condimentum. Augue dictum dolor elementum convallis dignissim malesuada commodo ultrices.",
    position: "CEO",
    name: "Ecom Web Page Design ",
    image: Image3,
  },
];

const Home = () => {
  return (
    <>
      <Section pt={"120"}>
        <Container>
          <Row>
            <Col lg={6} className="d-flex align-items-center">
              <div className={styles.hs_content}>
                <h6 className={styles.intro}>Hi, I am</h6>
                <h4 className={styles.name}>Ravindra Singh</h4>
                <h1 className={styles.title}>
                  Frontend <br /> <span>Developer</span>  
                </h1>
                <p className={styles.description}>
                  Lorem ipsum dolor sit amet consectetur. Tristique amet sed
                  massa nibh lectus netus in. Aliquet donec morbi convallis
                  pretium. Turpis tempus pharetra
                </p>
                <Button text={"Hire Me"} size={"small"} type={"fill"} />
              </div>
            </Col>
            <Col>
              <div className={styles.hs_image}>
                <img src={HsImg} alt="hero" />
                <SocialIcons />
              </div>
            </Col>
          </Row>
        </Container>
      </Section>

      <Section pt={"60"}>
        <Container>
          <Row>
            <Col md={6}>
              <div>
                <img src={abtImg} alt="" />
              </div>
            </Col>
            <Col className="d-flex align-items-center">
              <div>
                <SectionHeading
                  title={"About Me"}
                  des={
                    " Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra"
                  }
                />
                {ProgressData.map((data, i) => {
                  return (
                    <div key={i}>
                      <h6 className={styles.progress_label}>{data.label}</h6>
                      <ProgressBar now={data.percentage} />
                    </div>
                  );
                })}
              </div>
            </Col>
          </Row>
        </Container>
      </Section>

      <Section pt={"140"} pb={"140"}>
        <Container>
          <Row className="justify-content-center">
            <Col lg={8}>
              <div className={styles.service_heading}>
                <SectionHeading
                  title={"Services"}
                  des={
                    "Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium"
                  }
                />
              </div>
            </Col>
          </Row>
          <Row className="mt-4">
            {FeatureData.map((data, i) => (
              <Col lg={3} key={i}>
                <FeatureBox
                  title={data.title}
                  des={data.description}
                  Icon={data.icon}
                />
              </Col>
            ))}
          </Row>
        </Container>
      </Section>
      <Section>
        <Container>
          <Row className="justify-content-center">
            <Col lg={8}> 
              <div className={styles.service_heading}>
                <SectionHeading
                  title={"My Projects"}
                  des={
                    "Lorem ipsum dolor sit amet consectetur. Mollis erat duis aliquam mauris est risus lectus. Phasellus consequat urna tellus"
                  }
                />
              </div>
            </Col>
          </Row>
          <Row className="justify-content-center">
            <Col lg={10}>
              <div className={styles.project_tabs}>
                <Button text={"All"} size={"small"} type={"outline"} />
                <Button text={"UI /UX"} size={"small"} type={"outline"} />
                <Button text={"Web Design"} size={"small"} type={"fill"} />
                <Button text={"App Design"} size={"small"} type={"outline"} />
                <Button
                  text={"Graphic Design"}
                  size={"small"}
                  type={"outline"}
                />
              </div>
            </Col>
          </Row>
          <Row>
            {ProjectData.map((data, i) => (
              <Col lg={4} key={i}>
                <ProjectBox
                  title={data.title}
                  des={data.description}
                  Image={data.image}
                />
              </Col>
            ))}
          </Row>
        </Container>
      </Section>
      <Section pt={"140"} pb={"140"}>
        <Container>
          <Row className="justify-content-center">
            <Col lg={8}>
              <div className={styles.service_heading}>
                <SectionHeading
                  title={"Testimonials"}
                  des={
                    "Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium"
                  }
                />
              </div>
            </Col>
          </Row>
          <Row  className={styles.mt_72}>
            <Swiper
              slidesPerView={1}
              spaceBetween={30}
              loop={true}
              navigation={true}
              centeredSlides={true}
              // autoplay={{
              //   delay: 2500,
              //   disableOnInteraction: false,
              // }}
              keyboard={{
                enabled: true,
              }}
              pagination={{ clickable: true }}
              modules={[Keyboard,/* Autoplay, */ Navigation, Pagination]}
              className="mySwiper"
            >
              {TestData.map((data, i) => (
                <SwiperSlide key={i}> 
                    <TestimonialBox
                      name={data.name}
                      position={data.position}
                      Image={data.image}
                      quotes={data.quotes}
                    /> 
                </SwiperSlide>
              ))}
            </Swiper>
          </Row>
        </Container>
      </Section>
      <Section pb={"140"}>
        <Container>
          <Row className="justify-content-center">
            <Col lg={8}>
              <div className={styles.service_heading}>
                <SectionHeading
                  title={"Lets Design Together"}
                  des={
                    "Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium"
                  }
                />
                <div className={styles.contact_input}>
                  <input type="text" placeholder="Enter Your Email" />
                  <Button text={"Contact Me"} size={"large"} type={"fill"} />
                </div>
              </div>
            </Col>
          </Row>
          <Row></Row>
        </Container>
      </Section>
    </>
  );
};

export default Home;
