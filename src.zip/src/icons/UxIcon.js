import React from 'react'


const UxIcon = () => {
  return (
   <></>
  )
}

export default UxIcon